#!/usr/bin/env python3
"""
SIH26245 Ready-to-Use Computer Vision Detection CLI
Run standalone inference on any image, video, or live webcam.

Usage:
    # 1. Single Image Detection:
    python scripts/run_inference.py --source outputs/yolo_sample_frames/042.avi_frame_50pct.jpg --save

    # 2. CCTV Video Analysis:
    python scripts/run_inference.py --source data/yolo_videos/042.avi --video

    # 3. Live Webcam Stream:
    python scripts/run_inference.py --webcam

    # 4. JSON output for automated pipelines:
    python scripts/run_inference.py --source sample.jpg --json
"""

import sys
import os
import argparse
import json
import cv2

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.models.yolo_detector import TrainingCentreDetector


def main():
    parser = argparse.ArgumentParser(description="SIH26245 Vocational Training Centre YOLO Detector")
    parser.add_argument("--source", type=str, default="outputs/yolo_sample_frames/042.avi_frame_50pct.jpg",
                        help="Path to image, video file, or camera index (default: sample frame)")
    parser.add_argument("--model", type=str, default="sih_training_centre_yolo",
                        choices=["sih_training_centre_yolo", "yolov8n", "yolov8s"],
                        help="Model to use (default: sih_training_centre_yolo)")
    parser.add_argument("--conf", type=float, default=0.35, help="Confidence threshold (default: 0.35)")
    parser.add_argument("--device", type=str, default=None, help="Device: mps, cuda, or cpu (auto-detected by default)")
    parser.add_argument("--video", action="store_true", help="Analyze source as video file")
    parser.add_argument("--max-samples", type=int, default=15, help="Number of distributed keyframes to sample for video (default: 15)")
    parser.add_argument("--webcam", action="store_true", help="Launch live interactive webcam stream")
    parser.add_argument("--camera-id", type=int, default=0, help="Camera device index for webcam (default: 0)")
    parser.add_argument("--save", action="store_true", help="Save visual annotated image")
    parser.add_argument("--output", type=str, default="outputs/inference_result.jpg", help="Output path for saved image")
    parser.add_argument("--anonymize", action="store_true", help="Blur trainee faces for privacy compliance")
    parser.add_argument("--json", action="store_true", help="Print structured JSON output")

    args = parser.parse_args()

    print("=" * 70)
    print("SIH26245: AI Training Centre Monitoring & Compliance Detector")
    print("=" * 70)
    print(f"Model:      {args.model}")
    print(f"Confidence: {args.conf}")

    detector = TrainingCentreDetector(
        model_name=args.model,
        conf=args.conf,
        device=args.device
    )
    print(f"Loaded on:  {detector.device.upper()}")
    print("-" * 70)

    # Mode 1: Live Webcam Stream
    if args.webcam:
        print(f"Opening webcam camera device index {args.camera_id}...")
        print("Press 'q' in the OpenCV window to exit stream.")
        cap = cv2.VideoCapture(args.camera_id)
        if not cap.isOpened():
            print(f"Error: Could not open camera {args.camera_id}.")
            sys.exit(1)

        while True:
            ret, frame = cap.read()
            if not ret or frame is None:
                break

            result = detector.detect(frame, conf=args.conf, anonymize_faces=args.anonymize)
            annotated = result["annotated_frame"]
            cv2.imshow("SIH26245 Live YOLO Stream (Press 'q' to exit)", annotated)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()
        print("Webcam stream closed.")
        return

    # Mode 2: Video File Analysis
    if args.video or args.source.endswith((".avi", ".mp4", ".mov", ".mkv")):
        print(f"Analyzing video: {args.source}...")
        video_res = detector.detect_video(args.source, max_samples=args.max_samples, conf=args.conf)
        if args.json:
            print(json.dumps(video_res, indent=2))
        else:
            print(f"Duration:          {video_res['duration_sec']} seconds")
            print(f"Keyframes Sampled: {video_res['keyframes_sampled']}")
            print(f"Peak Attendance:   {video_res['peak_trainee_attendance']} trainees")
            print(f"Avg Attendance:    {video_res['avg_trainee_attendance']} trainees")
            print("Peak Infrastructure Objects:")
            for obj, cnt in video_res['peak_objects_breakdown'].items():
                print(f"  • {obj.capitalize():<12}: {cnt}")
            print(f"Processing Time:   {video_res['total_processing_time_sec']}s ({video_res['effective_fps']} FPS)")
        return

    # Mode 3: Single Image Detection
    save_path = args.output if args.save else None
    result = detector.detect(args.source, conf=args.conf, save_path=save_path, anonymize_faces=args.anonymize)

    if args.json:
        # Strip numpy frame before json serialize
        result.pop("annotated_frame", None)
        print(json.dumps(result, indent=2))
    else:
        print(f"Source Image:       {args.source}")
        print(f"Trainee Headcount:  {result['person_count']} persons")
        print(f"Total Detections:   {result['total_detections']}")
        print(f"Inference Latency:  {result['latency_ms']} ms")
        print("Detected Objects Breakdown:")
        for obj, cnt in result['objects_breakdown'].items():
            print(f"  • {obj.capitalize():<12}: {cnt}")
        if save_path:
            print(f"Annotated Image:    {save_path}")
    print("=" * 70)


if __name__ == "__main__":
    main()
