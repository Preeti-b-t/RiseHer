#!/usr/bin/env python3
"""
CLI Script to Initialise, Reset, or Authorise Official Authentication Accounts
Usage:
    python scripts/init_auth_accounts.py [--reset-passwords] [--approve-pending [email]] [--list]

Roles initialized:
    1. Government Officer:   username: gov_officer
    2. Centre 1 Member:      username: centre1_member
    3. Centre 2 Coordinator: username: centre2_coordinator
    4. Centre 3 Coordinator: username: centre3_coordinator

Passwords can be customized via environment variables:
    GOV_OFFICER_PASSWORD
    CENTRE1_MEMBER_PASSWORD
    CENTRE2_COORDINATOR_PASSWORD
    CENTRE3_COORDINATOR_PASSWORD
"""

import sys
import os

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.core.database import init_db, get_db
from app.services.auth_init import ensure_auth_accounts, INITIAL_ACCOUNTS


def list_users():
    init_db()
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, username, email, full_name, role, centre_id, is_active, is_verified, approval_status
            FROM users
            ORDER BY created_at ASC
        """)
        rows = cursor.fetchall()

    print("=" * 80)
    print(f"DATABASE USERS ({len(rows)} registered accounts)")
    print("=" * 80)
    for r in rows:
        d = dict(r)
        status_flag = f"[ACTIVE, {d.get('approval_status') or 'UNKNOWN'}]"
        ver_flag = "VERIFIED" if d.get('is_verified') else "UNVERIFIED"
        print(f"ID:       {d.get('id')}")
        print(f"Username: {d.get('username') or 'N/A'}")
        print(f"Email:    {d.get('email')}")
        print(f"Name:     {d.get('full_name')}")
        print(f"Role:     {d.get('role')} (Centre: {d.get('centre_id') or 'STATEWIDE'})")
        print(f"Status:   {status_flag} | Email: {ver_flag}")
        print("-" * 80)


def approve_pending(target_email: str = None):
    init_db()
    with get_db() as conn:
        cursor = conn.cursor()
        if target_email:
            cursor.execute("""
                UPDATE users SET
                    is_verified = 1,
                    approval_status = 'APPROVED',
                    updated_at = CURRENT_TIMESTAMP
                WHERE LOWER(email) = LOWER(?)
            """, (target_email.strip(),))
            affected = cursor.rowcount
            print(f"Approved {affected} user matching email: {target_email}")
        else:
            cursor.execute("""
                UPDATE users SET
                    is_verified = 1,
                    approval_status = 'APPROVED',
                    updated_at = CURRENT_TIMESTAMP
                WHERE approval_status = 'PENDING'
            """)
            affected = cursor.rowcount
            print(f"Approved {affected} pending user accounts.")


def main():
    args = sys.argv[1:]
    
    if "--list" in args or "-l" in args:
        list_users()
        return

    if "--approve-pending" in args:
        idx = args.index("--approve-pending")
        target = args[idx + 1] if idx + 1 < len(args) and not args[idx + 1].startswith("-") else None
        approve_pending(target)
        return

    force_reset = "--reset-passwords" in args or "-r" in args
    print("=" * 70)
    print("SIH26245: Initializing 4 Official Role-Based Authentication Accounts")
    print("=" * 70)
    
    init_db()
    result = ensure_auth_accounts(force_update_passwords=force_reset)
    
    print(f"Status: {result['status']}")
    print(f"Created: {result['created_count']} accounts")
    print(f"Updated: {result['updated_count']} accounts")
    print("-" * 70)
    print("Configured Accounts Summary:")
    for acc in INITIAL_ACCOUNTS:
        print(f" • Role: {acc['role_title']}")
        print(f"   Username:  {acc['username']}")
        print(f"   Email:     {acc['email']}")
        print(f"   Assigned:  {acc['centre_id'] or 'All Monitored Centres'}")
        print(f"   Scope:     {acc['description']}")
        print()
    print("=" * 70)
    print("Done. Accounts are ready for authenticated login.")


if __name__ == "__main__":
    main()
