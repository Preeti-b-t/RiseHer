"""
Dataset Preprocessing & Train/Val/Test Partitioning Script
Standardizes image resolutions and splits datasets without data leakage.
"""
import os
import shutil
import random
import argparse
import logging
from PIL import Image

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("prepare_dataset")

def prepare_yolo_dataset(
    source_images_dir: str,
    source_labels_dir: str,
    output_dir: str,
    train_ratio: float = 0.7,
    val_ratio: float = 0.2,
    test_ratio: float = 0.1,
    target_size: int = 640
):
    if not os.path.exists(source_images_dir):
        logger.error(f"Source images directory '{source_images_dir}' not found.")
        return False

    os.makedirs(os.path.join(output_dir, "images", "train"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "images", "val"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "images", "test"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "labels", "train"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "labels", "val"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "labels", "test"), exist_ok=True)

    image_files = [f for f in os.listdir(source_images_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
    random.seed(42)
    random.shuffle(image_files)

    total = len(image_files)
    n_train = int(total * train_ratio)
    n_val = int(total * val_ratio)

    splits = {
        "train": image_files[:n_train],
        "val": image_files[n_train:n_train + n_val],
        "test": image_files[n_train + n_val:]
    }

    logger.info(f"Splitting {total} samples: Train={len(splits['train'])}, Val={len(splits['val'])}, Test={len(splits['test'])}")

    for split_name, files in splits.items():
        for fname in files:
            src_img = os.path.join(source_images_dir, fname)
            dst_img = os.path.join(output_dir, "images", split_name, fname)
            
            # Normalize / Resize image while keeping aspect ratio
            try:
                with Image.open(src_img) as img:
                    img = img.convert("RGB")
                    img.thumbnail((target_size, target_size), Image.Resampling.LANCZOS)
                    img.save(dst_img, "JPEG", quality=90)
            except Exception as e:
                logger.warning(f"Error processing {fname}: {e}")
                continue

            # Copy label if present
            base = os.path.splitext(fname)[0]
            src_lbl = os.path.join(source_labels_dir, f"{base}.txt")
            dst_lbl = os.path.join(output_dir, "labels", split_name, f"{base}.txt")
            if os.path.exists(src_lbl):
                shutil.copy2(src_lbl, dst_lbl)

    logger.info(f"Dataset successfully prepared in '{output_dir}'.")
    return True

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Prepare dataset for YOLO model training")
    parser.add_argument("--images", default="data/raw/images", help="Path to raw images")
    parser.add_argument("--labels", default="data/raw/labels", help="Path to labels")
    parser.add_argument("--output", default="data/processed", help="Path to output directory")
    args = parser.parse_args()
    prepare_yolo_dataset(args.images, args.labels, args.output)
