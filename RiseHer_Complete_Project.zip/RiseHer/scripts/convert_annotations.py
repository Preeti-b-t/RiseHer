"""
Annotation Converter for Object Detection (VOC / COCO to YOLO format)
"""
import os
import json
import argparse
import logging
import xml.etree.ElementTree as ET

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("convert_annotations")

def convert_voc_xml_to_yolo(xml_file: str, class_map: dict) -> str:
    tree = ET.parse(xml_file)
    root = tree.getroot()
    
    size = root.find("size")
    if size is None:
        return ""
    w = int(size.find("width").text)
    h = int(size.find("height").text)
    
    yolo_lines = []
    for obj in root.findall("object"):
        cls_name = obj.find("name").text
        if cls_name not in class_map:
            continue
        cls_id = class_map[cls_name]
        bndbox = obj.find("bndbox")
        xmin = float(bndbox.find("xmin").text)
        ymin = float(bndbox.find("ymin").text)
        xmax = float(bndbox.find("xmax").text)
        ymax = float(bndbox.find("ymax").text)
        
        # YOLO normalized bounding box format: class x_center y_center width height
        x_center = ((xmin + xmax) / 2.0) / w
        y_center = ((ymin + ymax) / 2.0) / h
        bw = (xmax - xmin) / w
        bh = (ymax - ymin) / h
        
        yolo_lines.append(f"{cls_id} {x_center:.6f} {y_center:.6f} {bw:.6f} {bh:.6f}")
        
    return "\n".join(yolo_lines)

def convert_folder(xml_dir: str, out_dir: str, class_map: dict):
    os.makedirs(out_dir, exist_ok=True)
    xml_files = [f for f in os.listdir(xml_dir) if f.endswith(".xml")]
    for xml_file in xml_files:
        p = os.path.join(xml_dir, xml_file)
        lines = convert_voc_xml_to_yolo(p, class_map)
        base = os.path.splitext(xml_file)[0]
        out_p = os.path.join(out_dir, f"{base}.txt")
        with open(out_p, "w") as f:
            f.write(lines)
    logger.info(f"Converted {len(xml_files)} XML annotations to YOLO format in '{out_dir}'.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--xml_dir", default="data/raw/annotations")
    parser.add_argument("--out_dir", default="data/raw/labels")
    args = parser.parse_args()
    sample_classes = {"person": 0, "workbench": 1, "projector": 2, "computer": 3, "welding_machine": 4}
    if os.path.exists(args.xml_dir):
        convert_folder(args.xml_dir, args.out_dir, sample_classes)
    else:
        logger.info(f"Directory '{args.xml_dir}' not present. Converter ready for incoming dataset imports.")
