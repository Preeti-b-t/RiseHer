"""
Dataset Validation Pipeline Script
Performs integrity scans: corrupted images, bounding box bounds, missing labels, and class distribution.
"""
import os
import argparse
import logging
from PIL import Image

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("validate_dataset")

def validate_dataset(dataset_dir: str):
    logger.info(f"Initiating validation scan for dataset in: {dataset_dir}")
    images_dir = os.path.join(dataset_dir, "images")
    labels_dir = os.path.join(dataset_dir, "labels")

    if not os.path.exists(dataset_dir):
        logger.error("Dataset folder does not exist.")
        return False

    valid_images = 0
    corrupted_images = 0
    missing_labels = 0
    invalid_bboxes = 0

    image_extensions = ('.jpg', '.jpeg', '.png', '.bmp')
    all_files = []
    for root, _, files in os.walk(dataset_dir):
        for f in files:
            if f.lower().endswith(image_extensions):
                all_files.append(os.path.join(root, f))

    logger.info(f"Found {len(all_files)} total visual files to audit.")

    for img_path in all_files:
        # 1. Image integrity check
        try:
            with Image.open(img_path) as img:
                img.verify()
            valid_images += 1
        except Exception:
            corrupted_images += 1
            continue

        # 2. Check corresponding label file if in YOLO structure
        base_name = os.path.splitext(os.path.basename(img_path))[0]
        # Look for label file
        parent_dir = os.path.dirname(img_path)
        label_candidate = os.path.join(parent_dir.replace("images", "labels"), f"{base_name}.txt")
        if os.path.exists(label_candidate):
            with open(label_candidate, "r") as lf:
                for line in lf:
                    parts = line.strip().split()
                    if len(parts) >= 5:
                        try:
                            cls_id = int(parts[0])
                            xc, yc, w, h = float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4])
                            if not (0.0 <= xc <= 1.0 and 0.0 <= yc <= 1.0 and 0.0 <= w <= 1.0 and 0.0 <= h <= 1.0):
                                invalid_bboxes += 1
                        except ValueError:
                            invalid_bboxes += 1
        else:
            if "images" in img_path:
                missing_labels += 1

    report = {
        "dataset_path": dataset_dir,
        "scanned_files": len(all_files),
        "valid_images": valid_images,
        "corrupted_images": corrupted_images,
        "missing_labels": missing_labels,
        "invalid_bboxes": invalid_bboxes,
        "status": "PASSED" if corrupted_images == 0 and invalid_bboxes == 0 else "WARNINGS_FOUND"
    }

    print("\n=======================================================")
    print("DATASET VALIDATION AUDIT REPORT")
    print("=======================================================")
    for k, v in report.items():
        print(f"  {k:20s}: {v}")
    print("=======================================================\n")
    return report

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--path", default="data/processed", help="Path to dataset directory to validate")
    args = parser.parse_args()
    validate_dataset(args.path)
