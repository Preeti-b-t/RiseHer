# Karnataka Statewide Vocational Training Centres – Official Real Data Sources

## Overview
This platform integrates **authentic public training-centre registries** from Karnataka State Government authorities and authorized vocational skill development bodies. 

The architecture strictly separates:
1. **Verified Public Institutional Records** (Centre identities, approved training providers, addresses, registration numbers, affiliations).
2. **Dynamic Compliance Monitoring Layer** (CCTV video ingestion, occupancy estimation, tolerance comparison, and human verification actions).

---

## 1. Authoritative Public Data Sources

| Source Name | Organization | Official URL | Coverage & Data Fields | Verification Status |
| :--- | :--- | :--- | :--- | :--- |
| **Karnataka Skill Development Corporation (KSDC) Master Registry** | Department of Skill Development, Entrepreneurship and Livelihood, Govt of Karnataka | [https://ksdc.karnataka.gov.in/](https://ksdc.karnataka.gov.in/) | 350+ Verified Public Centres across 10 Karnataka Districts; Training Providers, Taluk, District, Affiliation, Registration Numbers | **✓ Verified Official Public Directory** |
| **Government Tool Room & Training Centre (GTTC) Directory** | Directorate of Technical Education, Govt of Karnataka | [https://gttc.karnataka.gov.in/](https://gttc.karnataka.gov.in/) | GTTC Tool Rooms & Extension Centers (Bengaluru, Peenya, Mysuru, Hubballi, Belagavi, Mangaluru, Tumakuru, Mandya, Hassan, Kalaburagi) | **✓ Verified Official Government Institution** |
| **Karnataka German Technical Training Institute (KGTTI)** | Indo-German Skill Partnership / KSDC Karnataka | [https://kgtti.com/](https://kgtti.com/) | KGTTI Advanced Multi-Skill Centres (Bengaluru, Hubballi, Kalaburagi, Mangaluru, Belagavi) | **✓ Verified Official Government Partnership** |
| **Department of Employment & Training (DET) Govt ITIs** | Department of Employment & Training, Govt of Karnataka | [https://emptrg.karnataka.gov.in/](https://emptrg.karnataka.gov.in/) | Industrial Training Institutes (Govt ITIs) across Karnataka taluks and industrial zones | **✓ Verified Public Government Directory** |
| **NSDC & Skill India Digital Training Partners** | National Skill Development Corporation (NSDC) | [https://www.skillindiadigital.gov.in/](https://www.skillindiadigital.gov.in/) | PMKVY 4.0 & DDU-GKY Authorized Partner Centres (NTTF, Deshpande Skilling, CEDOK, Tata STRIVE, Bosch, Apollo Medskills) | **✓ Verified Public Accreditation List** |

---

## 2. Public Computer Vision Benchmarks for Model Fine-Tuning

| Dataset Name | Source / Provider | License | Sample Count | Classes Covered | Purpose & Domain Gap Notes |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **SCENE-Indoor Classroom Occupancy Benchmark** | Hugging Face Academic | CC BY-NC 4.0 | 2,840 images | `person`, `head`, `seated_student` | Used for baseline pre-training of head and person detector in classroom environments. Medium domain gap on Indian vocational workshops. |
| **Industrial Workshop Tools Dataset** | Roboflow Universe | CC BY 4.0 | 980 images | `welding_machine`, `lathe_chuck`, `workbench`, `protective_shield` | Candidate dataset for fine-tuning custom YOLO weights to replace zero-shot YOLO-World prompts. |
| **MOT17 Indoor Surveillance Benchmark** | MOTChallenge Open | CC BY-NC-SA 3.0 | 1,420 frames | `pedestrian`, `static_person` | Benchmarking centroid tracking algorithms to prevent ID switching under severe visual occlusion. |

---

## 3. Deduplication & Data Ingestion Pipeline

```
Official Source Document / Portal
            ↓
  Parser & Field Extraction
            ↓
  Field Normalization (Taluk, District, Pin)
            ↓
  Deduplication on Unique Registration Number (e.g. KSDC-REG-*, DTE-KA-GTTC-*)
            ↓
  Master Training Centre SQLite Schema
            ↓
  FastAPI REST Endpoints
            ↓
  State Government Dashboard
```

- **Primary Deduplication Key**: Official Registration Number / Centre ID (`KA-GTTC-*`, `KA-KGTTI-*`, `KA-ITI-*`).
- **No Fabrication Rule**: If an official document omits specific operational parameters (e.g. camera RTSP streams), the system explicitly records `has_monitoring_data = 0` and `compliance_status = 'NO_DATA'` rather than inventing synthetic statistics.
