# Data Provenance & Ethics Architecture (PS SIH26245)

## Strict Separation of Public Data vs Synthetic Monitoring Telemetry

This document defines the data provenance rules enforced across the KSHAMATA-AI monitoring system. Every record presented in the UI, database, or API response is tagged with an immutable provenance classification.

---

## 1. Provenance Taxonomy & Badge Legend

| Provenance Type | UI Badge Text | Origin & Definition | Examples in System |
| :--- | :--- | :--- | :--- |
| **`PUBLIC_DATA`** | `[ PUBLIC GOVERNMENT REGISTRY ]` | Sourced from official public state government portals, accreditation lists, or public computer vision benchmarks. | GTTC, KGTTI, Govt ITI, NTTF centre profiles, SCENE-Indoor benchmark. |
| **`SYNTHETIC_DEMO`** | `[ SYNTHETIC DEMO MONITORING ]` | Artificially generated monitoring signals (attendance numbers, simulated CCTV video uploads) for prototype demonstration. | Simulated discrepancy scenarios, priority risk score rankings for demo centres. |
| **`USER_PROVIDED`** | `[ USER PROVIDED DATA ]` | Directly submitted by authorized training centre coordinators or trainers. | Daily batch attendance rosters, periodic infrastructure equipment self-declarations. |
| **`AI_INFERENCE`** | `[ AI INFERENCE ]` | Machine learning model predictions from computer vision pipelines. | YOLOv8 person count estimations, YOLO-World zero-shot equipment detections, luminance metrics. |
| **`HUMAN_VERIFIED`** | `[ OFFICIALLY VERIFIED ]` | Evaluated and confirmed by an authorized government compliance officer. | Final discrepancy validation, inspection dispatch orders, official review notes. |

---

## 2. Non-Accusatory Principles

1. **AI As Assistive Technology**: AI model inferences are treated as decision-support signals. The system never automatically accuses an institution of malpractice or fraud.
2. **Standardized Non-Accusatory Terminology**:
   - ✅ *"Possible discrepancy noted in attendance count"*
   - ✅ *"Requires verification by compliance officer"*
   - ✅ *"AI observation differs from reported value"*
   - ❌ *"Fraud detected"*
   - ❌ *"Fake attendance confirmed"*
3. **Tolerance Margin**: Discrepancies $\le 5\%$ are automatically classified as `GREEN (Normal)` to account for seating occlusion and natural classroom movements.
4. **Persistence Rule**: Discrepancies require 3+ consecutive sessions of variance before being elevated to persistent priority.

---

## 3. Privacy-by-Design Architecture

- **Automatic Face Blurring**: All visual evidence frames extracted from video feeds have Gaussian face blurring applied (`radius = 31`) before being stored on disk.
- **Aggregate Occupancy Counting**: Attendance monitoring is performed via head and person presence counting, strictly avoiding mandatory biometric face recognition.
- **Data Retention Windows**:
  - Raw un-anonymized CCTV video: Automatically purged after **7 days**.
  - Anonymized discrepancy evidence snapshots: Retained for **90 days** for official audit logs.
