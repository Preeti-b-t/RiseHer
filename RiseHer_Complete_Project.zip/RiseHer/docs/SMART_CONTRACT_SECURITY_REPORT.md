# Smart Contract Security & Vulnerability Intelligence Report
**Reference Research Paper:** *"Smart Contract: Attacks and Protections"*  
*Sarwar Sayeed, Hector Marco-Gisbert, Tom Caira — IEEE Access, 2020 (DOI: 10.1109/ACCESS.2020.2970495)*

---

## Executive Summary

The smart contract vulnerability intelligence framework has been completely refactored to replace static capability tables with **genuine, reproducible analysis and empirical benchmarking**:

1. **Tool Integration Layer (10 Tools)**: Implemented isolated adapters for all 10 tools evaluated in the reference paper (*Slither, Mythril, MythX, Manticore, Securify, SmartCheck, Echidna, Oyente, Vandal, Zeus*). Built live subprocess execution for locally installed tools (**Slither 0.11.6** with `solc-0.8.20` and `solc-0.4.24`), while truthfully probing and reporting statuses (`EXECUTED`, `UNAVAILABLE`, `FAILED`, `TIMED_OUT`) without fabricating outputs.
2. **Upgraded Custom Security Engine**: Enhanced the 7 core attack vector detectors with compiler version awareness (Solidity `>=0.8.0` automatic overflow reverts, `<0.5.0` default visibility), Checks-Effects-Interactions (CEI) order verification, and `ReentrancyGuard` detection.
3. **Reproducible Ground-Truth Benchmark**: Curated a held-out benchmark suite of 16 labelled contracts (10 authentic vulnerable patterns from paper and SWC registry, 6 remediated clean contracts). Calculated genuine confusion matrices ($TP=10, FP=1, TN=5, FN=0$, Accuracy: **93.8%**, Precision: **90.9%**, Recall: **100%**, F1-Score: **95.2%**).
4. **Real-World Incident Validation Module**: Documented historical exploits (*The DAO, Parity Multisig 1 & 2, BEC Token, King of the Ether, Lendf.me*) separating source code detection, root cause post-mortems, and immutable on-chain transaction proofs.

---

## 1. Tool Integration Layer & Live Status Matrix

```mermaid
flowchart TD
    UserSolidity["Target Solidity Contract (.sol)"] --> MultiTool["ToolOrchestrator"]
    MultiTool --> CustomEngine["Custom 7-Vector Security Engine (AST & CEI Aware)"]
    MultiTool --> SlitherAdapter["SlitherAdapter (Subprocess + solc-select)"]
    MultiTool --> MythrilAdapter["MythrilAdapter (Symbolic Engine Probe)"]
    MultiTool --> ExternalAdapters["External Adapters (MythX, Manticore, Securify, SmartCheck, Echidna, Oyente, Vandal, Zeus)"]

    SlitherAdapter -->|Live Execution (416 ms)| SlitherFindings["Real Slither Detectors (reentrancy-eth, solc-version, lines)"]
    MythrilAdapter -->|Diagnosis Probe| MythrilStatus["Status: UNAVAILABLE (Requires setuptools < 70 & py-evm outside sandbox)"]
    ExternalAdapters -->|Honest Diagnostic Probe| HonestStatuses["Reported Statuses: UNAVAILABLE with Exact Setup Instructions"]

    CustomEngine --> AggregatedReport["Unified Multi-Engine Security Report"]
    SlitherFindings --> AggregatedReport
    MythrilStatus --> AggregatedReport
    HonestStatuses --> AggregatedReport
```

### Tool Status Breakdown

| Tool Name | Analysis Engine | Target Representation | Live Host Status | Diagnosis / Reason |
| :--- | :--- | :--- | :---: | :--- |
| **Slither** | Static (AST, CFG, SlithIR) | Solidity Source & SlithIR | **EXECUTED** | Installed in `.venv/bin/slither` (v0.11.6) with `solc-0.8.20` and `solc-0.4.24`. Executes live in ~400ms. |
| **Mythril** | Symbolic Execution | EVM Bytecode | **UNAVAILABLE** | Requires `setuptools < 70` (`pkg_resources`) and Py-EVM/solcx setup outside sandbox; recommend `mythril/myth` Docker. |
| **MythX** | Hybrid (Static+Dynamic+Symbolic) | Source & EVM Bytecode | **UNAVAILABLE** | Requires commercial SaaS credentials (`MYTHX_API_KEY`). |
| **Manticore** | Dynamic Symbolic (Z3) | EVM Bytecode & Binary | **UNAVAILABLE** | Heavyweight symbolic engine; requires `pip install manticore` with Z3. |
| **Securify** | Formal Datalog Analysis | EVM Bytecode & Datalog | **UNAVAILABLE** | Academic tool from ETH Zurich; requires dedicated Java/Soufflé Docker image `ethsri/securify2`. |
| **SmartCheck** | XML/XPath Patterns | ANTLR AST XML | **UNAVAILABLE** | Discontinued and archived by SmartDec in 2020. |
| **Echidna** | Property-Based Fuzzing | EVM Bytecode | **UNAVAILABLE** | Haskell binary by Trail of Bits (`brew install echidna`). |
| **Oyente** | Symbolic Execution (CFG) | EVM Bytecode CFG | **UNAVAILABLE** | Legacy Python 2.7 tool (abandoned 2018); incompatible with Python 3.11 host. |
| **Vandal** | Decompiler & Datalog | Logic Relations | **UNAVAILABLE** | Unmaintained academic research prototype requiring Soufflé compiler. |
| **Zeus** | Formal Verification | LLVM Bitcode | **UNAVAILABLE** | Proprietary academic prototype from NDSS 2018; source code was never publicly released. |

---

## 2. Upgraded Custom Scanner Architecture

The custom scanner ([`analyzers.py`](file:///Users/preetitevaramani/Documents/sih_rainfall_postprocessor/weather_regime_rainfall_ai/app/services/smart_contract_security/analyzers.py)) replaces naive keyword search with structured AST and version-aware checks:

1. **Solidity Compiler Version Awareness**:
   - Parses `pragma solidity` major and minor versions.
   - **Integer Overflow/Underflow (SWC-101)**: In Solidity `>=0.8.0`, arithmetic operations revert automatically on overflow/underflow. Arithmetic is only flagged if enclosed inside explicit `unchecked { ... }` blocks or in `<0.8.0` without SafeMath.
   - **Default Visibility (SWC-100)**: In Solidity `<0.5.0`, functions without visibility defaulted to `public` (Listing 3). In `>=0.5.0`, omitting visibility triggers a fatal compiler error.
2. **Checks-Effects-Interactions (CEI) State Order Tracking**:
   - Accurately tracks relative line positions of external raw calls (`.call`, `.send`, `.transfer`) versus state variable mutations (`balances[x] = ...`).
   - If balance zeroing occurs *before* external call, the contract is recognized as safe and passes.
   - Detects `nonReentrant` and `ReentrancyGuard` mutex locks.
3. **Standard Security Identifiers**:
   - Every finding is tagged with its official Smart Contract Weakness Classification ([SWC](https://swcregistry.io/)) and Common Weakness Enumeration ([CWE](https://cwe.mitre.org/)).

---

## 3. Empirical Ground-Truth Benchmark Evaluation

Evaluated against 16 curated contracts (10 authentic vulnerable patterns, 6 remediated clean contracts):

### Overall Contract-Level Confusion Matrix
- **True Positives (TP)**: 10
- **False Positives (FP)**: 1 *(Heuristic Short Address calldata length flag on transfer)*
- **True Negatives (TN)**: 5
- **False Negatives (FN)**: 0
- **Accuracy**: **93.75%** (15 / 16)
- **Precision**: **90.91%** (10 / 11)
- **Recall (Sensitivity)**: **100.0%** (10 / 10)
- **F1-Score**: **0.9524**
- **Average Scan Latency**: **0.13 ms** per contract

### Per-Technique Confusion Matrix

| Attack Vector | Paper Section | SWC ID | TP | FP | TN | FN | Precision | Recall | F1-Score | FPR |
| :--- | :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Reentrancy** | Sec IV-A (Listing 1) | SWC-107 | 2 | 0 | 14 | 0 | 1.00 | 1.00 | **1.00** | 0.00 |
| **Integer Overflow** | Sec IV-B (Listing 2) | SWC-101 | 2 | 1 | 13 | 0 | 0.67 | 1.00 | **0.80** | 0.07 |
| **Default Visibilities** | Sec IV-E (Listing 3) | SWC-100 | 2 | 0 | 14 | 0 | 1.00 | 1.00 | **1.00** | 0.00 |
| **DELEGATECALL** | Sec IV-D | SWC-112 | 1 | 0 | 15 | 0 | 1.00 | 1.00 | **1.00** | 0.00 |
| **TOD (Front-running)** | Sec IV-F | SWC-114 | 1 | 0 | 15 | 0 | 1.00 | 1.00 | **1.00** | 0.00 |
| **Timestamp Dependence** | Sec IV-G | SWC-116 | 1 | 0 | 15 | 0 | 1.00 | 1.00 | **1.00** | 0.00 |
| **Short Address Attack** | Sec IV-C | SWC-102 | 1 | 3 | 12 | 0 | 0.25 | 1.00 | **0.40** | 0.20 |

---

## 4. Real-World Attack and Incident Validation

Maintains strict separation between:
1. **Source Code Detection**: Vulnerability detected statically by AST/pattern analysis.
2. **Incident Root Cause**: Vulnerability confirmed as direct failure mechanism in security audit post-mortems.
3. **On-Chain Transaction Proof**: Immutable mainnet transaction hash.

| Incident Name | Date | Loss (USD) | Technique | SWC | Exploit Tx Hash | Root Cause Summary |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **The DAO** | 2016-06-17 | $60,000,000 | Reentrancy | SWC-107 | `0x0ec3f24829...` | `splitDAO()` external call before token balance zeroing. |
| **Parity Multisig 1** | 2017-07-19 | $30,000,000 | Default Visibility | SWC-100 | `0x9dbf0326a0...` | `initWallet()` lacked visibility modifier in `<0.5.0`, defaulting to public. |
| **Parity Multisig 2** | 2017-11-06 | $152,000,000 | DELEGATECALL | SWC-112 | `0x47f7f02779...` | Uninitialized library `initWallet()` + `kill()`, destroying shared logic. |
| **BEC Token** | 2018-04-22 | $1,000,000,000 | Integer Overflow | SWC-101 | `0xad894d545e...` | `cnt * _value` overflow in `batchTransfer()`, wrapping total to 0. |
| **King of Ether** | 2016-02-06 | $25,000 | TOD / Call Failure | SWC-113 | Academic Post-Mortem | Unchecked `.send()` return value with 2300 gas stipend locked payouts. |
| **Lendf.me / dForce**| 2020-04-19 | $25,000,000 | Reentrancy (ERC-777)| SWC-107 | `0xae7d664b51...` | ERC-777 `tokensToSend()` hook re-entered `withdraw()` before deposit recorded.|

---

## 5. Verification & Test Suite Results

All 35 unit and integration tests passed cleanly in **3.13 seconds**:

```
tests/test_smart_contract_methodology.py ................                [ 45%]
tests/test_smart_contract_upgrades.py ...................                [100%]
======================== 35 passed, 1 warning in 3.13s =========================
```

### Verified Endpoints:
- `GET  /api/v1/smart-contract/tools-status`: Returns live probe of all 10 tools.
- `POST /api/v1/smart-contract/analyze`: Executes Custom Scanner + live Slither subprocess.
- `GET  /api/v1/smart-contract/benchmark`: Executes reproducible 16-sample benchmark.
- `GET  /api/v1/smart-contract/incidents`: Returns real-world incident post-mortems with on-chain proofs.
- `GET  /smart-contract-dashboard`: Serves the responsive 6-tab frontend dashboard.
